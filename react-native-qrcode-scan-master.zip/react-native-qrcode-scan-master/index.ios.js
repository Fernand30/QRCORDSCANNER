import { AppRegistry } from 'react-native';
import camera from './App/camera/nav';

const App = camera;

AppRegistry.registerComponent('test', () => App);