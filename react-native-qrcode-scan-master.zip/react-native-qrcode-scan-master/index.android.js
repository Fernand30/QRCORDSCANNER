/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import { AppRegistry } from 'react-native';
import camera from './App/camera/nav';

const App = camera;

AppRegistry.registerComponent('test', () => App);
