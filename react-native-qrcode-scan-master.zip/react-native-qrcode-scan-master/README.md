## react-native-qrcode-scan
基于 React Native Camera 实现二维码扫描

<img src="http://me.lizhooh.com/$resource/image/2017/2/rn-qrcode.png" />

## 来自于我的博客
<a href="http://me.lizhooh.com/2017/02/28/React Native/React Native Camera 实现二维码扫描/" >React Native Camera 实现二维码扫描</a>

